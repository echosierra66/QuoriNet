class SpatialQuoriNetV2(nn.Module):
    def __init__(self, in_channels=STATE_CHANNELS):
        # Channels: P1 pos, P2 pos, H-wall, V-wall, P1 walls-left, P2 walls-left, P1 path-dist, P2 path-dist
        super().__init__()
        if in_channels != STATE_CHANNELS:
            raise ValueError(
                f"SpatialQuoriNetV2 requires {STATE_CHANNELS} input channels, "
                f"got {in_channels}"
            )
        self.in_channels = in_channels
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.value_head = nn.Sequential(
            nn.Linear(64, 64), nn.ReLU(),
            nn.Linear(64, 1), nn.Tanh()
        )

    def forward(self, x):
        expected = (self.in_channels, BOARD_SIZE, BOARD_SIZE)
        if not isinstance(x, torch.Tensor):
            raise TypeError(f"network input must be a torch.Tensor, got {type(x).__name__}")
        if x.ndim != 4 or tuple(x.shape[1:]) != expected:
            raise ValueError(
                f"network input must have shape [B, {self.in_channels}, "
                f"{BOARD_SIZE}, {BOARD_SIZE}], got {tuple(x.shape)}"
            )
        if x.shape[0] < 1:
            raise ValueError("network input batch cannot be empty")
        if x.dtype != torch.float32:
            raise TypeError(f"network input must have dtype torch.float32, got {x.dtype}")
        x = self.conv(x)
        x = self.pool(x).flatten(1)
        value = self.value_head(x)
        expected_output = (x.shape[0], VALUE_WIDTH)
        if tuple(value.shape) != expected_output:
            raise RuntimeError(
                f"network output must have shape {expected_output}, got {tuple(value.shape)}"
            )
        return value

class PolicyValueQuoriNet(SpatialQuoriNetV2):
    """Keep the complete V2 value path; learn spatial action priors beside it.

    forward remains scalar for existing UI, diagnostics, and value opponents.
    policy_value is the shared-trunk, two-head training/search interface.
    """
    supports_policy = True

    def __init__(self, in_channels=STATE_CHANNELS):
        super().__init__(in_channels)
        self.policy_head = nn.Conv2d(64, 3, 1)
        nn.init.zeros_(self.policy_head.weight)
        nn.init.zeros_(self.policy_head.bias)

    def policy_value(self, states):
        features = self.conv(states)
        spatial = self.policy_head(features)
        logits = torch.cat((spatial[:, 0].flatten(1),
                            spatial[:, 1, :8, :8].flatten(1),
                            spatial[:, 2, :8, :8].flatten(1)), dim=1)
        return logits, self.value_head(self.pool(features).flatten(1))
