class ResidualBlock(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(64, 64, 3, padding=1, bias=False), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1, bias=False), nn.BatchNorm2d(64),
        )

    def forward(self, features):
        return torch.relu(features + self.layers(features))

class PolicyValueQuoriNet(nn.Module):
    """Final two-head network: eight residual blocks and spatially aware heads."""
    supports_policy = True

    def __init__(self, in_channels=STATE_CHANNELS):
        super().__init__()
        if in_channels not in (8, STATE_CHANNELS):
            raise ValueError(f"network requires {STATE_CHANNELS} input channels")
        self.in_channels = in_channels
        self.input_shape = (in_channels, BOARD_SIZE, BOARD_SIZE)
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, padding=1, bias=False),
            nn.BatchNorm2d(64), nn.ReLU(),
            *(ResidualBlock() for _ in range(8)),
        )
        self.policy_features = nn.Sequential(
            nn.Conv2d(64, 32, 1, bias=False), nn.BatchNorm2d(32), nn.ReLU(),
        )
        self.policy_head = nn.Conv2d(32, 3, 1)
        self.value_head = nn.Sequential(
            nn.Conv2d(64, 8, 1, bias=False), nn.BatchNorm2d(8), nn.ReLU(),
            nn.Flatten(), nn.Linear(8 * BOARD_SIZE * BOARD_SIZE, 64), nn.ReLU(),
            nn.Linear(64, 1), nn.Tanh(),
        )

    def _features(self, states):
        if not isinstance(states, torch.Tensor):
            raise TypeError("network input must be a torch.Tensor")
        if states.ndim != 4 or tuple(states.shape[1:]) != self.input_shape or states.shape[0] < 1:
            raise ValueError(f"network input must have shape [B, {self.input_shape}] with B >= 1")
        if states.dtype != torch.float32:
            raise TypeError("network input must have dtype torch.float32")
        return self.conv(states)

    def forward(self, states):
        return self.value_head(self._features(states))

    def policy_value(self, states):
        features = self._features(states)
        spatial = self.policy_head(self.policy_features(features))
        logits = torch.cat((spatial[:, 0].flatten(1),
                            spatial[:, 1, :8, :8].flatten(1),
                            spatial[:, 2, :8, :8].flatten(1)), dim=1)
        return logits, self.value_head(features)
